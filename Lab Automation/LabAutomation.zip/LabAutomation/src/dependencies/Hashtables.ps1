
$SoftwarePackageMapping = @{
    'Notepad++' = @{ package = 'Notepad++.exe'; CommandLine = '/S'}
    'WinRar' = @{ package = 'Winrar.exe'; CommandLine = '/S'}
}    

$OperatingSystemMapping = @{
    'Windows Server 2019 Standard' = 'Windows Server 2019 Standard (Desktop Experience)'
    'Windows Server 2019 Datacenter' = 'Windows Server 2019 Datacenter (Desktop Experience)'
    'Windows Server 2016 Standard' = 'Windows Server 2016 Standard (Desktop Experience)'
    'Windows Server 2016 Datacenter' = 'Windows Server 2016 Datacenter (Desktop Experience)'
    'Windows Server 2012 Standard' = 'Windows Server 2012 Standard (Desktop Experience)'
    'Windows Server 2012 Datacenter' = 'Windows Server 2012 Datacenter (Desktop Experience)'
    'Windows Server 2012 R2 ' = 'Windows Server 2012 R2 Standard (Server with a GUI)'
    'Windows Server 2008 R2 ' = 'Windows Server 2008 R2 (Full Installation)'
    'Windows 7 (x86)' = 'Windows 7 Professional'
    'Windows 7 (x64)' = 'Windows 7 Professional'
    'Windows 8.1 (x86)' = 'Windows 8.1 Pro'
    'Windows 8.1 (x64)' = 'Windows 8.1 Pro'
    'Windows 10 (x86)' = 'Windows 10 Pro'
    'Windows 10 (x64)' = 'Windows 10 Pro'
}