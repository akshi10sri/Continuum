1. Networking
2. Storage
3. Install custom roles
4. Installing Windows features
5. Can support pre-configured templates like- Small,Medium,Large Exchange 2016 Lab or SQL labs
6. Software Deployment page and config
7. Hypervisor reporting and status - Memory, Cores, Storage, Num of VMs
8. Confluence integration to document Automated Builds
9. JIRA integration for Approvals - process oriented approach
10. Could be used as a product to sell our customers to manage their Hyper-v infrastructure 