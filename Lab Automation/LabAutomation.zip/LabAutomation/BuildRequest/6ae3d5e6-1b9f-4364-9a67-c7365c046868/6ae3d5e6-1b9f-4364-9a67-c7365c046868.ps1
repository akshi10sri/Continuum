Start-Transcript -Force -Path "D:\Workspace\LabAutomation\BuildRequest\6ae3d5e6-1b9f-4364-9a67-c7365c046868\6ae3d5e6-1b9f-4364-9a67-c7365c046868.log"
Import-Module AutomatedLab
if((Get-Lab -List) -eq "snehal"){
Import-Lab -Name snehal -ErrorAction SilentlyContinue
Remove-Lab -Name snehal -Confirm:$false -ErrorAction SilentlyContinue
}
New-LabDefinition -Name snehal -DefaultVirtualizationEngine HyperV  -VmPath D:\VHD\
Add-LabVirtualNetworkDefinition -Name sn001 -AddressSpace 192.168.2.1/24
$installationCredential = New-Object PSCredential("admin", ("admin" | ConvertTo-SecureString -AsPlainText -Force))
Add-LabMachineDefinition -Name snhdc01 -Memory 4GB -OperatingSystem 'Windows Server 2016 Standard (Desktop Experience)' -Roles RootDC -DomainName snehal.com -Processors 2 -IpAddress 192.168.2.1
$installationCredential = New-Object PSCredential("admin", ("admin" | ConvertTo-SecureString -AsPlainText -Force))
Add-LabMachineDefinition -Name snhcl01 -Memory 2GB -OperatingSystem 'Windows Server 2016 Standard (Desktop Experience)' -Roles WebServer -DomainName snehal.com -Processors 1 -IpAddress 192.168.2.2 -InstallationUserCredential $installationCredential
$installationCredential = New-Object PSCredential("admin", ("admin" | ConvertTo-SecureString -AsPlainText -Force))
Add-LabMachineDefinition -Name snhcl02 -Memory 2GB -OperatingSystem 'Windows Server 2016 Standard (Desktop Experience)' -Roles FileServer -DomainName snehal.com -Processors 1 -IpAddress 192.168.2.3 -InstallationUserCredential $installationCredential
Install-Lab
Install-LabSoftwarePackage -ComputerName snhcl01,snhcl02 -Path D:\LabSources\SoftwarePackages\Notepad++.exe -CommandLine /S -AsJob
Install-LabSoftwarePackage -ComputerName snhcl01,snhcl02 -Path D:\LabSources\SoftwarePackages\winrar.exe -CommandLine /S -AsJob
Get-Job -Name 'Installation of*' | Wait-Job | Out-Null
Checkpoint-LabVM -All -SnapshotName 1
Show-LabDeploymentSummary -Detailed
