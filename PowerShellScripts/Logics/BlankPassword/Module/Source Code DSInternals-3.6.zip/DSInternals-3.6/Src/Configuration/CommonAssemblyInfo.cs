﻿using System.Reflection;

[assembly: AssemblyProduct("DSInternals PowerShell Module")]
[assembly: AssemblyCopyright("Copyright © 2015-2019 Michael Grafnetter. All rights reserved.")]