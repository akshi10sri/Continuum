﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DSInternals.Common.Test
{
    [TestClass]
    public class ValidatorTester
    {
        [TestMethod]
        public void Validator_TestMethod1()
        {
            throw new AssertInconclusiveException();
        }
    }
}
