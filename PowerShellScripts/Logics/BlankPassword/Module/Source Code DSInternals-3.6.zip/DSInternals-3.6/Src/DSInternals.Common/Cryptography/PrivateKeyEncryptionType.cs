﻿namespace DSInternals.Common.Cryptography
{
    public enum PrivateKeyEncryptionType : int
    {
        None = 0,
        PasswordRC4 = 1,
        PasswordRC2CBC = 2
    }
}