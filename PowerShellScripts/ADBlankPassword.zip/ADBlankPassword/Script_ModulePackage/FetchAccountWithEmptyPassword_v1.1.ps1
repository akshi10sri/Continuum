<#

 .SYNOPSIS
  Get list of samaccountnames whose passwords are blank.
 
 .DESCRIPTION
  Get list of samaccountnames whose passwords are blank with the help Active Directory database file NTDS.dit and system Boot Key.

 .PRE-REQUISITES
  - Minimum PowerShell Version - 3.0
  - Minimum .Net Framework - 4.5.1
  - Modified DSInternals Module that is packaged with this script
  - Script should be run locally on Domain Controller with admin privileges

 .NOTES
    File Name    - FetchAccountWithEmptyPassword.ps1
    File Version - 1.1
    Dated        - 23-10-2019
    Author       - Akshi Srivastava

  Thanks to Michael Grafnetter for creating DSInternals module which is being used by this script.

#>

$ErrorActionPreference = "Stop"
#***********************************************************************************************
# OS Architecture Check
#***********************************************************************************************
if ($env:PROCESSOR_ARCHITEW6432 -eq "AMD64") {
    #write-warning "Excecuting the script under 64 bit powershell"
    if ($myInvocation.Line) {
        &"$env:systemroot\sysnative\windowspowershell\v1.0\powershell.exe" -NonInteractive -NoProfile $myInvocation.Line
    }
    else {
        &"$env:systemroot\sysnative\windowspowershell\v1.0\powershell.exe" -NonInteractive -NoProfile -file "$($myInvocation.InvocationName)" $args
    }
    exit $lastexitcode
}

#***********************************************************************************************
#OS Version and Powershell Version comparison on the machine.
#***********************************************************************************************
try {
    [double]$OSVersion = [Environment]::OSVersion.Version.ToString(2)
    If (($osversion -lt '6.2') -or ($PSVersionTable.PSVersion.Major -lt '3')) {
        Write-Output "`nPrerequisites to run the script is not valid, Hence script exceution will be stopped"
        $OS = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue).ProductName
        if ($Null -ne $OS) {
            Write-Output "[MSG] : Operating System : $OS "
        }
        EXIT
    }
}
catch {
    Write-Output "`n[ERROR] : $($_.Exception.Message)"
    EXIT
}

#***********************************************************************************************
#Check status of VSS service
#***********************************************************************************************
try {
    $vss_service = Get-Service -Name "VSS" 
    if($vss_service.Status -eq "Stopped"){
        Start-Service -Name 'VSS'
        Start-Sleep -Seconds 5
        if((Get-Service -Name 'VSS').Status -eq "Stopped"){
            Write-Output "`n[MSG] : VSS service is stopped. Hence script execution will be stopped."
            Exit
        }
    }
}
catch {
    Write-Output "`n[ERROR] : $($_.Exception.Message)"
    EXIT
}

#***********************************************************************************************
#Check whether current machine is a domain controller
#***********************************************************************************************
try{
    $OSInfo = Get-WmiObject -Class Win32_OperatingSystem -Property * -ErrorAction Stop
    if ($OSInfo.ProductType -ne 2) {
        Write-Output "`n[MSG] : Current machine is not a domain controller"
        EXIT
    }
}
catch{
    Write-Output "`n[ERROR] : $($_.Exception.Message)"
    EXIT
}

#***********************************************************************************************
#Delete copies of NTDS.dit file and bootkey
#***********************************************************************************************
Function Delete-Folder{
    param($foldername)
    try{
        if((Test-Path $foldername) -eq $true){
            Write-Output "`n[MSG] : Deleting `'$foldername`'..."
            Remove-Item -Path "$foldername" -Recurse -Force
            if($? -eq $true){
                Write-Output "`n[MSG] : `'$foldername`' folder deleted"
            }
            else{
                Write-Output "`n[MSG] : Unable to delete `'$foldername`'"
            }
        }
    }
    catch{
        Write-Output "`n[ERROR] : $($_.Exception.Message)"
        Exit
    }
}


#***********************************************************************************************
#Extract NTDS.dit file and System key
#***********************************************************************************************
try{
    Write-Output "`n[MSG] : Finding directory of NTDS.dit file..."
    $path = (get-itemproperty -path "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" |Select-Object -Property 'DSA Working Directory').'DSA Working Directory'
    if(($null -ne $path) -and ((Test-Path $path) -eq $true)){
        Write-Output "`n[MSG] : Creating a folder in directory..."
        $folder = (New-Item -Path "$path" -Name "NTDSBackup$(get-date -Format yyyy-MM-dd-hh-mm-ss)" -ItemType Directory -Force).FullName
        Write-Output "[MSG] : Extracting NTDS.dit file and Boot key to path `'$folder`'...`n"
        $result = Invoke-Expression -Command 'ntdsutil.exe "ac i ntds" "ifm" "create full $folder" q q'
        if($result[22] -like "IFM media created successfully*"){
            Write-Output "[MSG] : NTDS.dit and Boot key are successfully copied to folder `'$folder`'"
        }
        else{
            Write-Output "[MSG] : Unable to extract NTDS.dit and Boot key"
            $result
            Delete-Folder -foldername $folder
            Exit
        }
    }
    else{
        Write-Output "`n[MSG] : Could not find directory of NTDS.dit file from the registry"
        Exit
    }
}
catch{
    Write-Output "`n[ERROR] : $($_.Exception.Message)"
    Delete-Folder -foldername $folder
    Exit
}

#***********************************************************************************************
#Import module
#***********************************************************************************************

try {
    Write-Output "`n[MSG] : Loading module..."
    Import-Module "C:\Users\Administrator\Downloads\DSInternals_v3.6.1\DSInternals\DSInternals.psd1"
}
catch {
    Write-Output "`n[ERROR] : Unable to load module ($($_.Exception.Message))"  
    Delete-Folder -foldername $folder
    Exit  
}

#***********************************************************************************************
#getting list of accounts with blank password
#***********************************************************************************************

try {
    Write-Output "`n[MSG] : Getting boot key..."
    if((Test-Path "$folder\registry\SYSTEM") -eq $true){
        $key = Get-BootKey -SystemHiveFilePath "$folder\registry\SYSTEM"
        if ($key) {
            Write-Output "`n[MSG] : Getting samaccountnames with empty password..."
            if((Test-Path "$folder\Active Directory\ntds.dit") -eq $true){
                $data = Get-ADDBAccount -DatabasePath "$folder\Active Directory\ntds.dit" -BootKey $key -All|Select-Object Samaccountname, NTHash
                $count = 0
                foreach($i in $data){
                    If($null -eq $i.NTHash){
                        write-output "$($i.Samaccountname)"
                        $count+=1
                    }
                }
                if ($count -eq 0) {
                    Write-Output "`n[MSG] : No samaccountname are found with blank password"
                }
            }
            else {
                Write-Output "`[MSG] : NTDS.dit file does not exist in folder `'$folder`'"
            }
        }
        else{
            Write-Output "[MSG] : Unable to get boot key of system"
        }
    }
    else {
        Write-Output "[MSG] : Boot key does not exist in `'$folder`'"
    }
}
catch {
    Write-Output "`n[ERROR] : Unable to fetch account names from NTDS.dit file ($($_.Exception.Message))"  
}

#***********************************************************************************************
#Delete copies of NTDS.dit file and bootkey
#***********************************************************************************************
Delete-Folder -foldername $folder

$ErrorActionPreference = "Continue"


